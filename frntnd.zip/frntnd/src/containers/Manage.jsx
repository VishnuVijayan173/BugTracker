import React,{ useEffect, useState }from 'react';
import {Table} from 'react-bootstrap';

import {Button,ButtonToolbar } from 'react-bootstrap';
import { FaEdit } from 'react-icons/fa';
import { RiDeleteBin5Line } from 'react-icons/ri';
import AddBugModal from './AddBugModal';
import UpdateBugModal from './UpdateBugModal';
import { deleteBug, getBugs } from '../services/BugServices';




const Manage = () => {
    const [bugs, setBugs] = useState([]);
    const [addModalShow, setAddModalShow] = useState(false);
    const [editModalShow, setEditModalShow] = useState(false);
    const [editBug, setEditBug] = useState([]);
    const [isUpdated, setIsUpdated] = useState(false);

    useEffect(() => {
       let mounted = true;
       if(bugs.length && !isUpdated) {
        return;
        }
       getBugs()
         .then(data => {
           if(mounted) {
             setBugs(data);
           }
         })
       return () => {
          mounted = false;
          setIsUpdated(false);
       }
     }, [isUpdated, bugs])

    const handleUpdate = (e, bug) => {
        e.preventDefault();
        setEditModalShow(true);
        setEditBug(bug);
    };

    const handleAdd = (e) => {
        e.preventDefault();
        setAddModalShow(true);
    };

    const handleDelete = (e, bugID) => {
        if(window.confirm('Are you sure ?')){
            e.preventDefault();
            deleteBug(bugID)
            .then((result)=>{
                alert(result);
                setIsUpdated(true);
            },
            (error)=>{
                alert("Failed to Delete Bug");
            })
        }
    };

    let AddModelClose=()=>setAddModalShow(false);
    let EditModelClose=()=>setEditModalShow(false);
    return(
        <div className="container-fluid side-container">
        <div className="row side-row" >
        <p id="manage"></p>
            <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
                <thead>
                <tr>
                  <th >BugID</th>
                  <th>Bug Name</th>
                  <th>Bug Description</th>
                  <th>Bug Satus</th>
                  <th>Project</th>
                  <th>Raised By</th>
                  <th>Action</th>
                </tr>
                </thead>
                {/* <tbody>
                  { bugs.map((bug) =>

                  <tr key={bug.id}>
                  <td>{bug.BugId}</td>
                  <td>{bug.BugName}</td>
                  <td>{bug.BugDescription}</td>
                  <td>{bug.BugStatus}</td>
                  <td>{bug.Project}</td>
                  <td>{bug.RaisedBy}</td>
                  <td>

                  <Button className="mr-2" variant="danger"
                    onClick={event => handleDelete(event,bug.BugID)}>
                        <RiDeleteBin5Line />
                  </Button>
                  <span>&nbsp;&nbsp;&nbsp;</span>
                  <Button className="mr-2"
                    onClick={event => handleUpdate(event,bug)}>
                        <FaEdit />
                  </Button>
                  <UpdateBugModal show={editModalShow} Bug={editBug} setUpdated={setIsUpdated}
                              onHide={EditModelClose}></UpdateBugModal>
                </td>
                </tr>)}
              </tbody> */}
              <tbody>
              { bugs.map((bug) =>{
                <tr key={bug.BugID}>
                
                <td>{bug.BugName}</td>
                <td>{bug.BugDescription}</td>
                <td>{bug.BugStatus}</td>
                <td>{bug.Project}</td>
                <td>{bug.RaisedBy}</td>
                  </tr>
              })}
              </tbody>
            </Table>
            <ButtonToolbar>
                <Button variant="primary" onClick={handleAdd}>
                Add Bug
                </Button>
                <AddBugModal show={addModalShow} setUpdated={setIsUpdated}
                onHide={AddModelClose}></AddBugModal>
            </ButtonToolbar>
        </div>
        </div>
    );
};

export default Manage;