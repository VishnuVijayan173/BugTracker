import React from "react";

import SideBar from "../containers/SideBar";
import View from "../containers/View";
import Bugs from "../containers/Bugs";
import './Dashboard.css';
import {BrowserRouter, Route, Switch, Routes, Redirect, Router ,Outlet} from 'react-router-dom';
function Dashboard() {
    return (
        <div>


    {/* <SideBar/> */}

    <div className="renderContent">
            <SideBar/>
            <Outlet />
    </div>
    </div>
    )
}
export default Dashboard;