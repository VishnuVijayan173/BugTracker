import React from 'react';
import Table from 'react-bootstrap/Table';
import { Button } from 'react-bootstrap';

function View() {
  return (
    <Table striped bordered hover>
      <thead>
        <tr>
          <th>#</th>
          <th>Bug Name</th>
          <th>Bug Status</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>1</td>
          <td>Mark</td>
          <td>Otto</td>
          <td>
          <Button variant="primary" size="sm">
          View
        </Button>{' '}
        <Button variant="primary" size="sm">
          Edit
        </Button>{' '}
        <Button variant="primary" size="sm">
          Delete
        </Button>
          </td>
        </tr>
        <tr>
          <td>2</td>
          <td>Jacob</td>
          <td>Thornton</td>
          <td>
          <Button variant="primary" size="sm">
          View
        </Button>{' '}
        <Button variant="primary" size="sm">
          Edit
        </Button>{' '}
        <Button variant="primary" size="sm">
          Delete
        </Button>
          </td>
        </tr>
        <tr>
          <td>3</td>
          <td >Larry </td>
          <td>Thornton</td>
          <td>
          <Button variant="primary" size="sm">
          View
        </Button>{' '}
        <Button variant="primary" size="sm">
          Edit
        </Button>{' '}
        <Button variant="primary" size="sm">
          Delete
        </Button>
          </td>
        </tr>
      </tbody>
    </Table>
  );
}

export default View;