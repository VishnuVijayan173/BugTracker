import React, { useEffect, useState } from 'react';
import { Table, ButtonToolbar } from 'react-bootstrap';
import { FaEdit } from 'react-icons/fa';
import { RiDeleteBin5Line } from 'react-icons/ri';
import AddBugModal from './AddBugModal';
import UpdateBugModal from './UpdateBugModal';
import axios from 'axios';
import { deleteBug, getBugs } from '../services/BugServices';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { toast } from 'react-toastify';


const Manage = () => {
  const [data, setData] = useState([]);
  const [addModalShow, setAddModalShow] = useState(false);
  const [editModalShow, setEditModalShow] = useState(false);
  const [editBug, setEditBug] = useState({});
  const [isUpdated, setIsUpdated] = useState(false);
  const [show, setShow] = useState(false);

  const [BugId, setBugId] = useState("");
  const [BugName, setBugName] = useState("");
  const [BugDescription, setBugDescription] = useState("");
  const [BugStatus, setBugStatus] = useState("");
  const [Project, setProject] = useState("");
  const [RaisedBy, setRaisedBy] = useState("");

  const [editBugId, setEditBugId] = useState("");
  const [editBugName, setEditBugName] = useState("");
  const [editBugDescription, setEditBugDescription] = useState("");
  const [editBugStatus, setEditBugStatus] = useState("");
  const [editProject, setEditProject] = useState("");
  const [editRaisedBy, setEditRaisedBy] = useState("");

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);




  useEffect(() => {
    axios.get('https://localhost:44306/api/Bug')
      .then(res => setData(res.data))
      .catch(err => console.log(err));
  }, []);

  const handleUpdate = (bugID) => {
  handleShow();
  axios.get(`https://localhost:44306/api/Bug/${bugID}`)
  .then((result)=>{
    setEditBugId(id);
    setEditBugName(result.data.bugName);
    setEditBugDescription(result.data.bugDescription);
    setEditBugStatus(result.data.bugStatus);
    setEditProject(result.data.project);
    setEditRaisedBy(result.data.raisedBy);

  })
  .catch((error)=> {
    console.log(error);
  })

   
  };

  const handleAdd = (e) => {
    e.preventDefault();
    setAddModalShow(true);
  };

  const handleDelete = (bugID) => {
    if(window.confirm("Are you sure to delete")==true){
      axios.delete(`https://localhost:44306/api/Bug/${bugID}`)
      .then((result)=>{
        if(result.status === 200){
          toast.success('Bug has been deleted');
        }
      })
      .catch((error)=>{
        toast.error(error);
      })
        }
  };

  const  handleEdit =()=>{
    const url=`https://localhost:44306/api/Bug/${editBugID}`;
    const data = {
      "id": editBugID,
      "bugName": editBugName,
    "bugDescription": editBugDescription,
    "bugStatus": editBugStatus,
    "project": editProject,
    "raisedBy": editRaisedBy 
    }
    <axios.put(url,data)
      .then((result)=>{
        getBugs();
          toast.success('Bug has been deleted');
        }).catch((error)=>{
          toast.error(error);
        })
  }

  let AddModelClose = () => setAddModalShow(false);
  let EditModelClose = () => setEditModalShow(false);
  return (
    <div className="container-fluid side-container">
      <div className="row side-row">
        <p id="manage"></p>
        <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
          <thead>
            <tr>
              <th >BugID</th>
              <th>Bug Name</th>
              <th>Bug Description</th>
              <th>Bug Satus</th>
              <th>Project</th>
              <th>Raised By</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((bug) =>
              <tr key={bug.bugID}>
                <td>{bug.bugID}</td>
                <td>{bug.bugName}</td>
                <td>{bug.bugDescription}</td>
                <td>{bug.bugStatus}</td>
                <td>{bug.project}</td>
                <td>{bug.raisedBy}</td>
                <td>
                  <Button className="mr-2" variant="danger"
                    onClick={() => handleDelete(bug.bugID)}>
                    <RiDeleteBin5Line />
                  </Button>
                  <span>&nbsp;&nbsp;&nbsp;</span>
                  <Button className="mr-2"
                    onClick={() => handleUpdate(bug.bugID)}>
                    <FaEdit />
                  </Button>
                  
                </td>
              </tr>
            )}
              </tbody>

        </Table>
        <ButtonToolbar>
          <Button variant="primary" onClick={handleAdd}>
            Add Bug
          </Button>
          <AddBugModal show={addModalShow} setUpdated={setIsUpdated}
            onHide={AddModelClose}></AddBugModal>


        </ButtonToolbar>
        <Modal show={show} onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Edit details</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <div className="container">
          <div>
          <label>Bug Name</label>
            <input type="text" className="form-control" placeholder="Enter BugName"
            value={editBugName} onChange={(e)=> setEditBugName(e.target.value)}
            />
            </div>
          <div>
          <label>Bug Description</label>
            <input type="text" className="form-control" placeholder="Enter description"
            value={editBugDescription} onChange={(e)=> setEditBugDescription(e.target.value)}
            />
            </div>
          <div>
          <label>Bug Status</label>
            <input type="text" className="form-control" placeholder="Enter Status"
            value={editBugStatus} onChange={(e)=> setEditBugStatus(e.target.value)}
            />
            </div>
          <div>
          <label>Project</label>
            <input type="text" className="form-control" placeholder="Enter Project"
            value={editProject} onChange={(e)=> setEditProject(e.target.value)}
            />
            </div>
          <div>
          <label>Raised By</label>
            <input type="text" className="form-control" placeholder="Raised By"
            value={editRaisedBy} onChange={(e)=> setEditRaisedBy(e.target.value)}
            />
            </div> 
          </div>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleClose}>
            Close
          </Button>
          <Button variant="primary" onClick={handleEdit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
      </div>
    </div>
  );
};

export default Manage;