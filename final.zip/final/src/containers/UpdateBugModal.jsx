import React,{ useEffect, useState }from 'react';
import {Table} from 'react-bootstrap';

import {Button,ButtonToolbar } from 'react-bootstrap';
import { FaEdit } from 'react-icons/fa';
import { RiDeleteBin5Line } from 'react-icons/ri';
import {Modal, Col, Row, Form } from 'react-bootstrap';
import {FormControl, FormGroup, FormLabel} from 'react-bootstrap';
import { updateBug } from '../services/BugServices';
import axios from 'axios';



const UpdateBugModal = (bugID) => {
    const [editBugName, setEditBugName] = useState("");
    const [editBugDescription, setEditBugDescription] = useState("");
    const [editBugStatus, setEditBugStatus] = useState("");
    const [editProject, setEditProject] = useState("");
    const [editRaisedBy, setEditRaisedBy] = useState("");

    useEffect( () => {
        axios.get(`https://localhost:44306/api/Bug/${bugID}`).then((response) => {
            console.log(response);
            console.log(response.data[0].editBugName);
            setEditBugName(response.data[0].editBugName);
            setEditBugDescription(response.data[0].editBugDescription)
            setEditBugStatus(response.data[0].editBugStatus)
            setEditProject(response.data[0].editProject)
            setEditRaisedBy(response.data[0].editRaisedBy)

        })

    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();
        let Bug = { editBugName,editBugDescription,editBugStatus,editProject,editRaisedBy}
        console.log(Bug)
        var request = new XMLHttpRequest();
        request.onload = function () {
          if (this.readyState === 4 && this.status === 200) {
           console.log(this)
          }
        }
        request.open("PUT", `https://localhost:44306/api/Bug`);
        request.setRequestHeader('Content-type', 'application/json; charset=UTF-8');
        console.log(JSON.stringify(Bug))
        // Sending the request to the server
        request.send(JSON.stringify(Bug));
        window.location.href="http://localhost:3000/dashboard"

        }
    return(
        <div className="container">
            <Modal
                // {...props}
                size="lg"
                aria-labelledby="contained-modal-title-vcenter"
                centered >

                <Modal.Header closeButton>
                    <Modal.Title id="contained-modal-title-vcenter">
                        Update Bug Information
                    </Modal.Title>
                </Modal.Header>
                {/* <Modal.Body> */}
                    <Row>
                        <Col sm={6}>
                            <Form onSubmit={handleSubmit}>
                                <Form.Group controlId="BugName">
                                    <Form.Label>Bug Name</Form.Label>
                                    <Form.Control type="text" name="BugName" required  defaultValue={editBugName}  onClick={(e)=> setEditBugName(e.target.value)} placeholder=""/>
                            </Form.Group>

                            <Form.Group controlId="BugDescription">
                                    <Form.Label>Bug Description</Form.Label>
                                    <Form.Control type="text" name="BugDescription" required defaultValue={editBugDescription} onClick={(e)=> setEditBugDescription(e.target.value)} placeholder="" />
                            </Form.Group>
                            <Form.Group controlId="BugStatus">
                                    <Form.Label>Bug Status</Form.Label>
                                    <Form.Control type="text" name="BugStatus" required defaultValue={editBugStatus} onClick={(e)=> setEditBugStatus(e.target.value)} placeholder="" />
                            </Form.Group>
                            <Form.Group controlId="Project">
                                    <Form.Label>Project</Form.Label>
                                    <Form.Control type="text" name="Project" required defaultValue={editProject} onClick={(e)=> setEditProject(e.target.value)} placeholder="" />
                            </Form.Group>
                            <Form.Group controlId="RaisedBy">
                                    <Form.Label>Raised By</Form.Label>
                                    <Form.Control type="text" name="RaisedBy" required defaultValue={editRaisedBy} onClick={(e)=> setEditRaisedBy(e.target.value)} placeholder="" />
                            </Form.Group>
                            <Form.Group>
                                
                                <Button variant="primary" type="submit">
                                    Submit
                                </Button>
                            </Form.Group>
                            </Form>
                        </Col>
                    </Row>
                {/* </Modal.Body> */}
                <Modal.Footer>
                <Button variant="danger" type="submit">
                        Close
                </Button> 

                </Modal.Footer> 
            </Modal>
        </div>
    );
};


export default UpdateBugModal;

