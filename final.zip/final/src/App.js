
import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css"
import Login from './components/Login';
import SignUp from './components/SignUp';
import Dashboard from './components/Dashboard';
import Update from './components/Update';
import {BrowserRouter as Router,
        Switch,
        Route,
        Redirect,
        Routes
       }from 'react-router-dom';
import Bugs from './containers/Bugs';
import Manage from './containers/Manage';
import Home from './containers/Home';

import './App.css';

function App() {
  const title= 'Bug Tracker loading...';
  return (
    <div className="App">
{/* 
      <Router>
        <Routes>
          <Route exact path='/' component={Login}/>
          <Route exact path='/login' component={Login}/>
          <Route exact path='/signup' component={SignUp}/>
          <Route exact path='/dashboard' component={Dashboard}/>
        </Routes>
      </Router> */}
      <div >
        <Router>
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<SignUp />} />
            <Route path="update" element={<Update />} />
            <Route path="/dashboard" element={<Dashboard />}>
              <Route index element={<Home />} />
              <Route path="bugs" element={<Bugs />} />
              <Route path="manage" element={<Manage />} />
              <Route path="update" element={<Update />} />             
            </Route>
          </Routes>
          </Router>
        </div>
    </div>
  );
}

export default App;
