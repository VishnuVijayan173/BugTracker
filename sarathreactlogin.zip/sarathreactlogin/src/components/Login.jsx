import {useState} from 'react'
import { Link} from 'react-router-dom'



const Login =()=>{
    const [username,usernameupdate] = useState(' ');
    const [password,passwordupdate] = useState(' ');
    


const Handleclick =(e)=>{
    e.preventDefault();
    if(Validate()){
        console.log("proceed")
        fetch("http://localhost:5000/users" +username).then((res)=>{
            console.log(res)
            return res.json(); 
           
        }).then((resp)=>{
            // console.log(resp)
            if(Object.keys(resp).length==0){
                alert("please Enter the valid user name and password")
            }else{
                if(resp.password ===password){
                    alert("sucess")
                   

                }else{
                    alert("please Enter the valid credentaial")
                }
            }
        }).catch((err)=>{
            alert("login failed" +err.message)
        })
    }
}
   

const Validate =()=>{

    let result =true;

    if(username === '' || password === '' ) {

        result = false;

        alert('Please enter the username and password')
        }
        return result;
    
    }
    return(
        <div>
         <div className="row">
            <div className="offset-lg-3 col-lg-6" style={{ marginTop: '100px' }}>
                <form onSubmit={Handleclick} className="container">
                    <div className="card">
                        <div className="card-header">
                            <h2>User Login</h2>
                        </div>
                        <div className="card-body">
                            <div className="form-group">
                                <label>User Name <span className="errmsg">*</span></label>
                                <input type ='text 'value={username} onChange={e => usernameupdate(e.target.value)} className="form-control"></input>
                            </div>
                            <div className="form-group">
                                <label>Password <span className="errmsg">*</span></label>
                                <input type="password" value={password} onChange={e => passwordupdate(e.target.value)} className="form-control"></input>
                            </div>
                        </div>
                        <div className="card-footer">
                            <button type="submit" className="btn btn-primary"  >Login</button> |
                            <Link className="btn btn-success" to={'/register'}>New User</Link>
                        </div>
                    </div>
                </form>
            </div>
        </div>
        </div>
    )
}




export default Login;
