import React from "react";
import { Link } from "react-router-dom";
import ColorSchemesExample from "../containers/Navbar";
import SideBar from "../containers/SideBar";

function Dashboard() {
    return (
        
        <div className="container-fluid">
            <div className="container">
                <ColorSchemesExample/>
            </div>
            <div><SideBar/></div>
            <div className="container1" id="Home"></div>
            
        </div>
        
    )
}
export default Dashboard;