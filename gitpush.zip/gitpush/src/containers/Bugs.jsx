
import { Table } from 'react-bootstrap';
import { getBugs } from '../services/BugServices';
import '../App.css';



import React, { Component } from 'react';
import { render } from '@testing-library/react';
import { RestaurantMenu } from '@mui/icons-material';

export default class Bugs extends Component {
  state = {
    bugs: []
  }



  componentDidMount() {
    getBugs()
    .then(data => {
      this.setState((state, props) => ({
        bugs: data
      }));
    })
    .catch((error)=>{
      console.log(error)
    })
  }

  componentDidUpdate(prevProps, prevState) {
  
      console.log('This runs when the count property on state changes',this.state.bugs);
      
  }

 

  render() {
    return (
      <div className="container-fluid side-container">
      <div className="row side-row" >
       <p id="before-table"></p>
           <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
           <thead>
               <tr>
               <th>BugID</th>
               <th>Bug Name</th>
               <th>Bug Description</th>
               <th>Bug Status</th>
               <th>Project</th>
               <th>Raised By</th>
               </tr>
           </thead>
           <tbody>
               {this.state.bugs?.map((bug) =>
                <tr key={bug.bugID}>
                  <td>{bug.bugID}</td>
                  <td>{bug.bugName}</td>
                  <td>{bug.bugDescription}</td>
                  <td>{bug.bugStatus}</td>
                  <td>{bug.project}</td>
                  <td>{bug.raisedBy}</td>
                  <td>
                    
                  </td>
              </tr>
              
             )}
           </tbody>
       </Table>
       </div>
     </div>
    );
  }
}