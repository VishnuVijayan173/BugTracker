import React, { useEffect, useState } from 'react';
import { Table, Button, ButtonToolbar } from 'react-bootstrap';
import { FaEdit } from 'react-icons/fa';
import { RiDeleteBin5Line } from 'react-icons/ri';
import AddBugModal from './AddBugModal';
import UpdateBugModal from './UpdateBugModal';
import axios from 'axios';

const Manage = () => {
  const [data, setData] = useState([]);
  const [addModalShow, setAddModalShow] = useState(false);
  const [editModalShow, setEditModalShow] = useState(false);
  const [editBug, setEditBug] = useState({});
  const [isUpdated, setIsUpdated] = useState(false);

  useEffect(() => {
    axios.get('https://localhost:44306/api/Bug')
      .then(res => setData(res.data))
      .catch(err => console.log(err));
  }, []);

  const handleUpdate = (e, bug) => {
    e.preventDefault();
    setEditModalShow(true);
    console.log(id)

    window.location.href='http://localhost:3000/dashboard'+id;
  };

  const handleAdd = (e) => {
    e.preventDefault();
    setAddModalShow(true);
  };

  const handleDelete = (e, bugID) => {
    if (window.confirm('Are you sure ?')) {
      e.preventDefault();
      axios.delete(`https://localhost:44306/api/Bug/${bugID}`)
        .then((result) => {
          alert(result);
          setIsUpdated(true);
        },
          (error) => {
            alert("Failed to Delete Bug");
          })
    }
  };

  let AddModelClose = () => setAddModalShow(false);
  let EditModelClose = () => setEditModalShow(false);
  return (
    <div className="container-fluid side-container">
      <div className="row side-row">
        <p id="manage"></p>
        <Table striped bordered hover className="react-bootstrap-table" id="dataTable">
          <thead>
            <tr>
              <th >BugID</th>
              <th>Bug Name</th>
              <th>Bug Description</th>
              <th>Bug Satus</th>
              <th>Project</th>
              <th>Raised By</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {data.map((bug) =>
              <tr key={bug.bugID}>
                <td>{bug.bugID}</td>
                <td>{bug.bugName}</td>
                <td>{bug.bugDescription}</td>
                <td>{bug.bugStatus}</td>
                <td>{bug.project}</td>
                <td>{bug.raisedBy}</td>
                <td>
                  <Button className="mr-2" variant="danger"
                    onClick={event => handleDelete(event, bug.BugID)}>
                    <RiDeleteBin5Line />
                  </Button>
                  <span>&nbsp;&nbsp;&nbsp;</span>
                  <Button className="mr-2"
                    onClick={event => handleUpdate(event, bug.bugID)}>
                    <FaEdit />
                  </Button>
                  <UpdateBugModal show={editModalShow} Bug={editBug} setUpdated={setIsUpdated}
                    onHide={EditModelClose}></UpdateBugModal>
                </td>
              </tr>
            )}
              </tbody>

        </Table>
        <ButtonToolbar>
          <Button variant="primary" onClick={handleAdd}>
            Add Bug
          </Button>
          <AddBugModal show={addModalShow} setUpdated={setIsUpdated}
            onHide={AddModelClose}></AddBugModal>


        </ButtonToolbar>
      </div>
    </div>
  );
};

export default Manage;