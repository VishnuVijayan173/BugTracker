import axios from 'axios';

export async function getBugs() {
  const response = await axios.get('https://localhost:44306/api/Bug');
  return (response.data);
}

export  function deleteBug(BugID) {
  return axios.delete('https://localhost:44306/api/Bug' + BugID + '/', {
   method: 'DELETE',
   headers: {
     'Accept':'application/json',
     'Content-Type':'application/json'
   }
  })
  .then(response => response.data)
}

export  function addBug(bug){
  return axios.post('https://localhost:44306/api/Bug', {
    BugID:null,
    BugName:bug.BugName.value,
    BugDescription:bug.BugDescription.value,
    BugStatus:bug.BugStatus.value,
    Project:bug.Project.value,
    RaisedBy:bug.RaisedBy.value
  })
    .then(response=>response.data)
}

export function updateBug(bugid, bug) {
  return axios.put('https://localhost:44306/api/Bug' + bugid + '/', {
    BugName:bug.BugName.value,
    BugDescription:bug.BugDescription.value,
    BugStatus:bug.BugStatus.value,
    Project:bug.Project.value,
    RaisedBy:bug.RaisedBy.value
  })
   .then(response => response.data)
}

