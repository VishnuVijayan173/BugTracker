import React from "react";
import { Link } from "react-router-dom";

import SideBar from "../containers/SideBar";
import NavBar from "../containers/NavBar"
import Content from "../containers/Content";

import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import './Dashboard.css';



function Dashboard() {
    return (
        <>
        <NavBar/>
        <Container fluid className="Main-content">
            <Row className="full-width row-lg-2">
                <Col  className="col-xs-0 col-md-2 SideBar"><SideBar/></Col>
                <Col  className=" col-xs-12 col-md-10 RightContent"><Content/></Col>
            </Row>
        </Container>
      </>
        
        
    )
}
export default Dashboard;