
import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css"
import Login from './components/Login';
import SignUp from './components/SignUp';
import Dashboard from './components/Dashboard';
import {BrowserRouter as Router,
        Switch,
        Route,
        Redirect
       }from 'react-router-dom'

function App() {
  const title= 'Bug Tracker loading...';
  return (
    <div className="App">
      <Router>
        <Switch>
          <Route exact path='/' component={Login}/>
          <Route exact path='/login' component={Login}/>
          <Route exact path='/signup' component={SignUp}/>
          <Route exact path='/dashboard' component={Dashboard}/>
        </Switch>
      </Router>
      
    </div>
  );
}

export default App;
