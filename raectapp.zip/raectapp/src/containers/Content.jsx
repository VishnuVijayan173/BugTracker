import React from "react";

// import Create from "./Create";
import View from "./View";

const Content = () => {
    return (
    <body>
        <View/>
    </body>
    )
};
export default Content;