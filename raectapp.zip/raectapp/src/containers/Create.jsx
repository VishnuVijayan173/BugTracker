import React from "react";
import { Form, Button } from "react-bootstrap";
const Create = () => {
    return (
        <Form>
      <Form.Group className="mb-3" controlId="formGroupEmail">
        <Form.Label>Bug Name</Form.Label>
        <Form.Control required type="text" placeholder="Enter email" />
        <Form.Control.Feedback>Looks good!</Form.Control.Feedback>
      </Form.Group>
      <Form.Group className="mb-3" controlId="formGroupEmail">
        <Form.Label>Bug Description</Form.Label>
        <Form.Control required type="text" placeholder="Enter email" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formGroupEmail">
        <Form.Label>Bug Status</Form.Label>
        <Form.Control required type="text" placeholder="Enter email" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formGroupEmail">
        <Form.Label>Username</Form.Label>
        <Form.Control required type="text" placeholder="Enter email" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formGroupEmail">
        <Form.Label>Bug Name</Form.Label>
        <Form.Control required type="text" placeholder="Enter email" />
      </Form.Group>
      
      <Button variant="primary" type="submit">
        Submit
      </Button>
    </Form>
    )
};
export default Create;