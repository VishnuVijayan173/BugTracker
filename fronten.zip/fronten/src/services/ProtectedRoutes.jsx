import {React, useEffect} from "react";
import { Link, useNavigate } from "react-router-dom";


 
function ProtectedRoutes(props){
    const {Component} = props
     const navigate = useNavigate()
    useEffect(() => {
        let auth = localStorage.getItem('token');
        if(!auth){
            navigate("/");
            alert("Access denied...Login first!!")
            
            
        }
    }
    );
    return(
        <div>
            <Component/>
        </div>
    )
}
export default ProtectedRoutes;