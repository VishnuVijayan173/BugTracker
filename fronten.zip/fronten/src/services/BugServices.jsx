import axios from 'axios';

export async function getBugs() {
  const response = await axios.get('https://localhost:44306/api/Bug',{
    headers: {
      Authorization: `Bearer ${this.state.token}`,
    },
  });
  return (response.data);
}

export  function addBug(bug){
  return axios.post('https://localhost:44306/api/Bug', {
    BugID:null,
    BugName:bug.BugName.value,
    BugDescription:bug.BugDescription.value,
    BugStatus:bug.BugStatus.value,
    Project:bug.Project.value,
    RaisedBy:bug.RaisedBy.value
  })
    .then(response=>response.data)
}

export function updateBug(bugID, bug) {
  return axios.put('https://localhost:44306/api/Bug' + bugID+ '/', {
    BugName:bug.BugName,
    BugDescription:bug.BugDescription,
    BugStatus:bug.BugStatus,
    Project:bug.Project,
    RaisedBy:bug.RaisedBy
  })
   .then(response => response.data)
   .catch(err => console.log('Error: ', err))
}
export async function GetBugs() {
  const response = await axios.get('https://localhost:44306/api/Bug')
  .then(response => response.data)
    .catch(err => console.log('Error: ', err))
}

