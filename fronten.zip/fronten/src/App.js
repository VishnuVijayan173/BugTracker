
import React from 'react';
import "bootstrap/dist/css/bootstrap.min.css"
import SignUp from './container/SignUp';
import Login from './container/Login';
import Dashboard from './container/Dashboard';
import Update from './container/Update';
import {BrowserRouter as Router,
        Switch,
        Route,
        Redirect,
        Routes
       }from 'react-router-dom';
import Bugs from './components/Bugs';
import Manage from './components/Manage';
import Home from './components/Home';
import ProtectedRoutes from './services/ProtectedRoutes';
import './App.css';


function App() {
  const title= 'Bug Tracker loading...';
  return (
    <div className="App">

      <div >
        <Router>
          <Routes>
            <Route path="/" element={<Login />} />
            <Route path="/login" element={<Login />} />
            <Route path="/signup" element={<SignUp />} />
            <Route path="/dashboard" element={<ProtectedRoutes Component={Dashboard} />}>
              <Route index element={<ProtectedRoutes Component={Home} />} />
              <Route path="bugs" element={<ProtectedRoutes Component={Bugs} />} />
              <Route path="manage" element={<ProtectedRoutes Component={Manage} />} />
              <Route path="update" element={<ProtectedRoutes Component={Update} />} />             
            </Route>
          </Routes>
          </Router>
        </div>
    </div>
  );
}

export default App;
