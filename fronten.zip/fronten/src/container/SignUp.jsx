import React from "react";
import { Link } from "react-router-dom";
import  axios  from "axios";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";

function SignUp() {

  const [nameReg, setNameReg]= useState("");
  const [emailReg, setEmailReg]= useState("");
  const [projectReg, setProjectReg]= useState("");
  const [userNameReg, setUserNameReg]= useState("");
  const [passwordReg, setPasswordReg]= useState("");

  const navigate=useNavigate()

const register = (e) => {
  e.preventDefault();
  axios.post("https://localhost:44306/api/User/register", {
    name: nameReg,
    email: emailReg,
    project: projectReg,
    userName: userNameReg,
    password: passwordReg,
  }).then((response) => {
    console.log(response);
    toast.success("User registered Successfully");
    navigate('./login');
  });
};

  return(
    <div className="Auth-form-container">
      <ToastContainer/>
      <form className="Auth-form">
        <div className="Auth-form-content">
          <h3 className="Auth-form-title">Sign Up</h3>
          <div className="form-group mt-3">
            <label>Name</label>
            <input
              required
              type="text"
              className="form-control mt-1"
              placeholder="Enter Name"
              onChange={(e) => {
                setNameReg(e.target.value)
              }}
            />
          </div>
          <div className="form-group mt-3">
            <label>Email address</label>
            <input
              required
              type="email"
              className="form-control mt-1"
              placeholder="Enter email"
             
              onChange={(e) => {
                setEmailReg(e.target.value)
              }}
            />
          </div>
          <div className="form-group mt-3">
            <label>Project</label>
            <input
              required
              type="text"
              className="form-control mt-1"
              placeholder="Enter Project name"
              onChange={(e) => {
                setProjectReg(e.target.value)
              }}
            />
          </div>
          <div className="form-group mt-3">
            <label>Username</label>
            <input
              required
              type="text"
              className="form-control mt-1"
              placeholder="Enter Username"
              onChange={(e) => {
                setUserNameReg(e.target.value)
              }}
            />
          </div>
          <div className="form-group mt-3">
            <label>Password</label>
            <input
              required
              type="password"
              className="form-control mt-1"
              placeholder="Enter password"
              onChange={(e) => {
                setPasswordReg(e.target.value)
              }}
            />
          </div>
          <div className="d-grid gap-2 mt-3">
            <button onClick={register} type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
          <div>
            Already have account <Link to='/login'>Login</Link>
          </div>
        </div>
      </form>
    </div>
  )
}
export default SignUp;