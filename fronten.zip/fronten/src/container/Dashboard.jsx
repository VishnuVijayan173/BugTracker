import React from "react";
import SideBar from "../components/SideBar";
import Bugs from "../components/Bugs";
import './Dashboard.css';
import {BrowserRouter, Route, Switch, Routes, Redirect, Router ,Outlet} from 'react-router-dom';


function Dashboard() {
    return (
        <div>
    <div className="renderContent">
            <SideBar/>
            <Outlet />
    </div>
    </div>
    )
}
export default Dashboard;