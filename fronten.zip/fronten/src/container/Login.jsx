import React from "react";
import './Login.css';
import { Link, Redirect, useHistory } from "react-router-dom";
import  axios  from "axios";
import { useState } from "react";
import Dashboard from "./Dashboard";
import  {useNavigate} from 'react-router-dom'; 

function Login() {
  const [userName, setUserName]= useState("");
  const [password, setPassword]= useState(""); 
  const [loginStatus,setLoginStatus]=useState("");
  const navigate=useNavigate();

  const login = (e) => {
    e.preventDefault();
    axios.post("https://localhost:44306/api/User/authenticate", {
      userName: userName,
      password: password,
    }).then((response) => {

      console.log(response.data);
      if(response.status!==200){
        alert("invalid details")
        
      }
      else{
        localStorage.setItem('token', response.data.token);
        localStorage.setItem('auth',response.data.auth);
        alert("Login Success!")
        navigate('/dashboard')
        
        // return (<Redirect to ='/Dashboard'></Redirect>);
      }
        
      
    });
  };
  


  return(
    
    <div className="Auth-form-container">
      <form className="Auth-form" >
        <div className="Auth-form-content">
          <h3 className="Auth-form-title">Login</h3>
          <div className="form-group mt-3">
            <label>UserName</label>
            <input
              type="text"
              className="form-control mt-1"
              placeholder="Enter username"
              onChange={(e) => {
                setUserName(e.target.value)
              }}
            />
          </div>
          <div className="form-group mt-3">
            <label>Password</label>
            <input
              type="password"
              className="form-control mt-1"
              placeholder="Enter password"
              onChange={(e) => {
                setPassword(e.target.value);
              }}
            />
          </div>
          <div className="d-grid gap-2 mt-3">
            <button  onClick={login} type="submit" className="btn btn-primary">
              Submit
            </button>
          </div>
          <p> </p>
          <div>
            Don't have account <Link to='/signup'>Create</Link>
          </div>
        </div>
      </form>
    </div>
  )
}
export default Login;